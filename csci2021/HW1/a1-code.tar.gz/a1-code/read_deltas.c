#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "deltas.h"
#include <sys/stat.h>

int *read_text_deltas(char *fname, int *len){
  //Opening File
  FILE *fp;
  fp=fopen(fname, "r");

  if(fp==NULL){
    return NULL;
  }
  else{
    //Declaring Variables
    int point;
    int length=0;
    int value;
    int sum;
    //Loop to count number of integers in the file
    while((fscanf(fp,"%*d")!=EOF)){
      length++;
    }
    if(length==0){
      return NULL;
      fclose(fp);
    }
    //Dynamically allocating array
    int *array=malloc(sizeof(int)*length);
    rewind(fp);
    //loop to store values of file in dynamically allocated array
    for(int i=0;i<length;i++){
      fscanf(fp,"%d",&value);
      if(i==0){
        sum=value;
      }
      else{
        sum=sum+value;
      }
      array[i]=sum;
    }

    *len=length;
    //close file
    fclose(fp);
    return array;
  }
}

int *read_int_deltas(char *fname, int *len){
//opening file
  FILE *fp=fopen(fname,"r");
  if(fp==NULL){
    *len=-1;
    return NULL;
  }


  //finding file size
  struct stat sb;                                    // struct to hold
  int result = stat(fname, &sb);                     // unix system call to determine size of named file
  if(result==-1 || sb.st_size < sizeof(int)){        // if something went wrong or bail if file is too small
    *len=-1;
    fclose(fp);
    return NULL;
  }
  int total_bytes = sb.st_size;                      // size of file in bytes

  //allocating an array
  int *arr=malloc(total_bytes);
  //reading in integer data form
  int i=0;
  while(fread(&arr[i],sizeof(int),1,fp)){
    if(i==0){
      arr[i]=arr[i];
    }
    else{
      arr[i]=arr[i-1]+arr[i];
    }
    i++;
  }
  //closing file
  fclose(fp);
  return arr;
}
